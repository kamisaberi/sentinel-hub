#!/usr/bin/env bash
echo "[*] Triggering cleartext DICOM PHI exfiltration burst from 10.240.0.99..."
python3 -c 'print("Simulating C-STORE patient data exfiltration...")'
