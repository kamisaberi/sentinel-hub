#!/usr/bin/env bash
echo "[*] Triggering TRITON safety shutdown controller memory injection..."
tcpreplay -i eth0 -t /etc/sentinel/pcaps/triton_trisis_sis.pcap
